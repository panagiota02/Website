<?php
    $uname = $_POST['user'];
    $cps = $_POST['pass'];

    //to prevent sql injection
    $uname = stripcslashes($uname);
    $cps = stripcslashes($cps);
    $uname = mysql_real_escape_string($uname);
    $cps = mysql_real_escape_string ($cps);

    //connect to the server and select database
    mysql_connect("localhost","root","");
    mysql_select_db("synedrio7");

    //query the database for user
    $result = mysql_query("select * from panagiota where uname='$uname' 
    and cps='$cps'")
        or die ("Failed to query database ".mysql_error());
    $row = mysql_fetch_array($result);
    if ($row['uname'] == $uname && $row['cps'] == $cps)
    {
        header("Location: synedrio9.php");
    }
    else
    {
        header("Location: synedrio11.php");
	}
?>