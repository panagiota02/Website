<!DOCTYPE html>
<html>
<meta charset="utf-8"> 
<title>Συνέδριο 2021-2022</title>
<body>
<body style="background-color:silver">
<p style="text-align:center;font-size: 3em;"><strong>ΕΠΙΣΤΗΜΟΝΙΚΟ ΣΥΝΕΔΡΙΟ 2021-2022</p></strong>
<br>
<h2>Αποτυχία σύνδεσης, επαναλάβατε διαδικασία <a href="http://localhost/ergasia/synedrio8.php">LOGIN</a></h2>
</body>
</html>