-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2021 at 10:25 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `synedrio7`
--

-- --------------------------------------------------------

--
-- Table structure for table `panagiota`
--

CREATE TABLE IF NOT EXISTS `panagiota` (
  `uname` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cps` text NOT NULL,
  `firstname2` text NOT NULL,
  `lastname` text NOT NULL,
  `email` text NOT NULL,
  `pn` int(100) NOT NULL,
  `ps` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

--
-- Dumping data for table `panagiota`
--

INSERT INTO `panagiota` (`uname`, `id`, `cps`, `firstname2`, `lastname`, `email`, `pn`, `ps`) VALUES
('pana2007', 72, 'panag20', 'panagiota', 'Nikolaou', 'pana@gmail.com', 99999999, ''),
('pana200', 73, 'pana200', 'panagiota', 'Nikolaou', 'pana@gmail.com', 99999999, ''),
('kona210', 74, 'kona210', 'ÎšÏ‰Î½ÏƒÏ„Î±Î½Ï„Î¹Î±', 'Î£Î¿Ï†Î¿ÎºÎ»ÎµÎ¿Ï…Ï‚', 'konsof@gmail.com', 96578629, ''),
('715545dn', 75, '715545dn', 'Panagiota', 'SOFOKLEOUS', 'pana@gmailcom', 2147483647, ''),
('715545dn', 76, 'demis7', 'Panagiota', 'SOFOKLEOUS', 'pana@gmailcom', 2147483647, ''),
('715545dn', 77, 'demis7', 'Panagiota', 'SOFOKLEOUS', 'pana@gmailcom', 2147483647, ''),
('konsof', 78, 'konsof', 'ÎšÏ‰Î½ÏƒÏ„Î±Î½Ï„Î¹Î±', 'Î£Î¿Ï†Î¿ÎºÎ»ÎµÎ¿Ï…Ïƒ', 'konsofo@gmail.com', 96578629, ''),
('konsof', 79, 'konsof', 'ÎšÏ‰Î½ÏƒÏ„Î±Î½Ï„Î¹Î±', 'Î£Î¿Ï†Î¿ÎºÎ»ÎµÎ¿Ï…Ïƒ', 'konsofo@gmail.com', 96578629, ''),
('konsof', 80, 'konsof', 'ÎšÏ‰Î½ÏƒÏ„Î±Î½Ï„Î¹Î±', 'Î£Î¿Ï†Î¿ÎºÎ»ÎµÎ¿Ï…Ïƒ', 'konsofo@gmail.com', 96578629, ''),
('', 81, '', '', '', '', 0, ''),
('', 82, '', '', '', '', 0, ''),
('demis02', 83, 'demis02', 'panagiota', 'Nikolaou', 'pana@gmail.com', 96772181, ''),
('demis02', 84, 'demis02', 'panagiota', 'Nikolaou', 'pana@gmail.com', 96772181, ''),
('demis02', 85, 'demis02', 'panagiota', 'Nikolaou', 'pana@gmail.com', 96772181, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
