<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "synedrio7";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql ="INSERT INTO panagiota (uname,firstname2,lastname,email,pn,cps)
VALUES ('".$_POST['uname']."','".$_POST['firstname2']."','".$_POST['lastname']."','".$_POST['email']."','".$_POST['pn']."','".$_POST['ps']."')";


if ($conn->query($sql) === TRUE) {
  header("Location: synedrio8.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
  }
$conn->close();
?>
