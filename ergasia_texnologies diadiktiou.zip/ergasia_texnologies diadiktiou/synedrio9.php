<!DOCTYPE html>
<html>
<meta charset="utf-8"> 
<title>Συνέδριο 2021-2022</title>
<style>
.center {
  margin-left: auto;
  margin-right: auto;
}
</style>
<body>
<body style="background-color:silver;">
<p style="text-align:center;font-size: 3em;"><strong>ΕΠΙΣΤΗΜΟΝΙΚΟ ΣΥΝΕΔΡΙΟ 2021-2022</p></strong>
<table class="center" style="text-align:center;font-family: Arial, Helvetica, sans-serif;font-size: 2em;">
 <tr>
    <td>10:20</td>
	<td>ΠΕΡΑΣ ΠΡΟΣΕΛΕΥΣΗΣ ΚΟΙΝΟΥ</td>
	</tr>
	<tr>
    <td>10:30-10:45</td> 
	<td>ΠΑΡΟΥΣΙΑΣΗ ΟΜΙΛΗΤΩΝ</td>
	</tr>
	<tr>
    <td>10:45-11:45</td>
	<td>ΑΛΜΠΕΡΤ ΑΙΝΣΤΑΙΝ</td>
	</tr>
	<tr>
	<td>11:45-12:00</td>
	<td>ΔΙΑΛΕΙΜΜΑ</td>
	</tr>
	<tr>
	<td>12:00-13:00</td>
	<td>ΜΑΡΙΑ ΚΙΟΥΡΙ</td>
	 </tr>
	  
	<tr>
    <td>13:00-13:15</td>
    <td>ΔΙΑΛΕΙΜΜΑ</td>
    </tr>
	<tr>
	<td>13:15-14:15</td>
	<td>ΓΑΛΙΛΑΙΟΣ ΓΑΛΙΛΕΙ</td>
	</tr>
	<tr>
	<td>14:15-14:50</td>
	<td>ΕΡΩΤΗΣΕΙΣ ΑΠΟ ΤΟ ΚΟΙΝΟ</td>
	</tr>
	<tr>
	<td>15:00</td>
	<td>ΠΕΡΑΣ ΣΥΝΕΔΡΙΟΥ</td>
  </tr>
  </table>
  <img src="https://www.aftodioikisi.gr/wp-content/uploads/2017/12/diastima.jpg" alt="Image" width="372" height="200">
  <img src="https://lemesosblog.com/images/images-5/65f1bfdd50fa590a040ede511101795d.png" alt="Image" width="372" height="200">
  <img src="https://www.philenews.com/temp/images/1500x3000/cache_1500x3000_Analog_medium_867721_16836472_3112020.JPG" alt="Image" width="372" height="200">
  <img src="https://www.fortunegreece.com/wp-content/uploads/2016/11/27/space-odyssey.png" alt="Image" width="372" height="200">
  </body>
  </html>