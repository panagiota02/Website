<!DOCTYPE html>
<html>
<meta charset="utf-8"> 
<title>Συνέδριο 2021-2022</title>
<body>
<body style="background-color:silver">
<p style="text-align:center;font-size: 3em;"><strong>ΕΠΙΣΤΗΜΟΝΙΚΟ ΣΥΝΕΔΡΙΟ 2021-2022</p></strong>
<h2>Συμπληρώστε την παρακάτω φόρμα εγγραφής για δυνατότητα προβολής προγράμματος συνεδρίου</h2>
 <fieldset style="background-color:#400870;color:#FFFFFF";>
 <form id="mysynedrio" action="connect.php" method="post" style="text-align:center;font-size: 1.5em;">
 <strong><label  for="firstname2">Ονομά</label></strong>
 <input placeholder="Εισάγετε το όνομα σας" type="text" id="firstname2" name="firstname2" pattern="[a-zα-ωΑ-ΩA-Z]{4,12}" >
 <br>
 <strong><label  for="lastname">Επίθετο</label></strong>
 <input placeholder="Εισάγετε το επίθετο σας" type="text" id="lastname" name="lastname" pattern="[a-zα-ωΑ-ΩA-Z].{4,12}">
 <br>
 <input type="radio" id="sex" name="sex">
 Mr
 <input type="radio" id="sex" name="sex">
 Mrs
 <br>
 <strong><label for="email">E-mail</label></strong>
 <input placeholder="Εισάγετε E-mail" type="email" id="email" name="email" pattern="[a-z0-9].{1-20}@[a-z].{3-12}[a-z]">
 <br>
 <strong><label for="pn">Τηλέφωνο</label></strong>
 <input placeholder="Εισάγετε τηλέφωνο" type="text" id="pn" name="pn" pattern="[0-9].{5.10}">
 <br>
 <strong><label for="username1">Username</label></strong>
 <input placeholder="Λατινικά,6-8 χαρακτήρες" type="text" id="uname" name="uname" pattern="[a-z1-9].{5,8}">
 <br> 
 <strong><label for="ps">Password</label></strong>
 <input placeholder="Λατινικά,6-8 χαρακτήρες"type="password" id="ps" name="ps" pattern="[a-z1-9].{5,8}">
 <br> 
  <strong><label for="cps">Confirm Password</label></strong>
 <input type="password" id="cps" name="cps"pattern="[a-z1-9].{5,8}">
 <br>
  <input type="checkbox" id="accept" name="accept">
 <strong><label for="accept">Συμφωνείτε να λαμβάνετε ενημερωτικά email</label></strong><br>
 </body>
 <input value="Αποστολή" type="submit" name="btn">
 <input value="Ακύρωση" type="reset">
 <input type="hidden" name="con" id="con" value="0" >
 </fieldset>
  </form> 
 <p id="myp"></p>
<a href="http://localhost/ergasia/synedrio8.php"><p style="text-align:right;">NEXT</p></a>
<script>
 var password = document.getElementById("ps") , confirm_password = document.getElementById("cps");

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
	 </script>
  </body>
 </html>